
import './App.css';
import Function from './components/Function';
import Props from './components/Props';

function App() {
  return (
    <div className="App">
      <Function/>
      <Props/>
    </div>
  );
}

export default App;

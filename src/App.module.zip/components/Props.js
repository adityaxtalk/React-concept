import React from 'react'

const Header = (props) => {
    console.log(props)
    const data = props.data
  const { welcome, title, subtitle, author, date } = data
  const { firstName, lastName } = author
    return (
      <header>
        <div className='header-wrapper'>
        <h1>{welcome}</h1>
        <h2>{title}</h2>
        <h3>{subtitle}</h3>
        <p>
          {firstName} {lastName}
        </p>
        <small>{showDate(date)}</small>
        </div>
      </header>
    )
  }

  const Age = (props) => <div>The person is {props.age} years old.</div>
  const Weight = (props) => (
    <p>The weight of the object on earth is {props.weight} N.</p>
  )

  const Status = (props) => {
    // ternary operator to check the status of the person
    let status = props.status ? 'Old enough to drive' : 'Too young for driving'
    return <p>
       {props.status ? 'Old enough to drive': 'Too young for driving'}
    </p>
  }
  const Skills = (props) => {
  
    const skillList = props.skills.map((skill) => <li key={skill}>{skill}</li>)
    return <ul>{skillList}</ul>
  }



  const showDate = (time) => {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ]
  
    const month = months[time.getMonth()].slice(0, 3)
    const year = time.getFullYear()
    const date = time.getDate()
    return ` ${month} ${date}, ${year}`
  }

  const Button = (props) => <button onClick={props.onClick}>{props.text}</button>

const Props = () => {
    let currentYear = 2024
  let birthYear = 2000
  const age = currentYear - birthYear
  const gravity = 9.81
  const mass = 75
  

  let status = age >= 18
  const handleTime = () => {
    alert(showDate(new Date()))
  }
  const greetPeople = () => {
    alert('Welcome to 30 Days Of React Challenge, 2020')
  }
  const data = {
    welcome: 'Welcome to  React Tutorial',
    title: 'Getting Started React',
    subtitle: 'JavaScript Library',
    author: {
      firstName: 'Aditya',
      lastName: 'Kumar',
    },
    date: new Date(),
  }
// Destructure in one line
//   const {
//     welcome,
//     title,
//     subtitle,
//     author: { firstName, lastName },
//     date,
//   } = data
  return (
    <>
    <Header
      data={data}
    />

<Age age={age} />
<Weight weight={gravity * mass} />
<Status status={status} />
<Skills skills={['HTML', 'CSS', 'JavaScript']} />
<Button text='show time' onClick={()=> handleTime()} />
      <Button text='Greet People' onClick={greetPeople} />
    </>
  )
}

export default Props